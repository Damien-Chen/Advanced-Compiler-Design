#include "llvm/Transforms/Utils/IterIR.h"
#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Analysis/MemoryDependenceAnalysis.h"
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/STLExtras.h"
#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/Analysis/AliasAnalysis.h"
#include "llvm/Analysis/AssumptionCache.h"
#include "llvm/Analysis/MemoryDependenceAnalysis.h"
#include "llvm/Analysis/MemoryBuiltins.h"
#include "llvm/Analysis/MemoryLocation.h"
#include "llvm/Analysis/PHITransAddr.h"
#include "llvm/Analysis/TargetLibraryInfo.h"
#include "llvm/Analysis/ValueTracking.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Dominators.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/PredIteratorCache.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Use.h"
#include "llvm/IR/Value.h"
#include "llvm/InitializePasses.h"
#include "llvm/Pass.h"
#include "llvm/Support/AtomicOrdering.h"
#include "llvm/Support/Casting.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/Debug.h"
#include "llvm/IR/CFG.h"
#include "llvm/Support/raw_ostream.h"
#include <set>
#include <unordered_map>
#include <map>
#include <string>

using namespace llvm;

PreservedAnalyses IterIRPass::run(Function &F, FunctionAnalysisManager &AM){
//     for(BasicBlock &BB : F){
//       errs() << "Basick Block:" << BB.getName() <<"\n";
//       for(Instruction &I : BB){
//         errs() << "Instruction: " << I << "\n";
//       }
//     }
  void getAnalysisUsage(AnalysisUsage &AU) const {
    AU.addRequired<MemoryDependenceAnalysis>();
  }

  PreservedAnalyses run(Module &M, ModuleAnalysisManager &AM) {
    MemoryDependenceAnalysis &MDA = AM.getResult<MemoryDependenceAnalysis>(M);

    for (Function &F : M) {
      for (BasicBlock &BB : F) {
        for (Instruction &I : BB) {
          if (StoreInst *store = dyn_cast<StoreInst>(&I)) {
            MemoryLocation loc = MemoryLocation::get(store);
            NonLocalDepResult dep = MDA.getNonLocalPointerDependency(store, loc);
            if (dep.DepType == NonLocal && dep.NonLocalDeps.size() == 1) {
              Instruction *depInst = *dep.NonLocalDeps.begin();
              if (LoadInst *load = dyn_cast<LoadInst>(depInst)) {
                // The first if check whether the store and load access the same memory location
                // The second check whether the types of the value being load and stored are equal
                // The third check whether the actuval value being loaded or stored arre equal

                // If the above are all true, then the store instruction is redundant
                // and can be removed
                if (load->getPointerOperand() == store->getPointerOperand() &&
                    load->getType() == store->getType() &&
                    load->getOperand() == store->getValueOperand());
                  store->eraseFromParent();
                }
              }
            }
          }
        }
      }
    }
};
    return PreservedAnalyses::all();
}
